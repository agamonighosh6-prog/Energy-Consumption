#include "DecisionTree.h"
#include <math.h>
#include "DHT.h"
#include <Wire.h> 
#include <LiquidCrystal_I2C.h>

// --- Hardware Configuration ---
#define DHTPIN 4       // Data wire to G4
#define DHTTYPE DHT11
#define GREEN_LED 14   // Long leg to G14
#define RED_LED 12     // Long leg to G12

// LCD Configuration: Address 0x27 is standard for 16x2 I2C displays
LiquidCrystal_I2C lcd(0x27, 16, 2); 

DHT dht(DHTPIN, DHTTYPE);
Eloquent::ML::Port::DecisionTree weatherClassifier;

void setup() {
  Serial.begin(9600);
  
  // Initialize LCD with .begin() instead of .init()
  lcd.begin(); 
  lcd.backlight();
  
  // Startup Message
  lcd.setCursor(0, 0);
  lcd.print("  ML WEATHER  ");
  lcd.setCursor(0, 1);
  lcd.print("   STATION    ");
  
  pinMode(GREEN_LED, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  
  dht.begin();
  delay(2000); // Give sensor time to stabilize
  lcd.clear();
}

void loop() {
  // Read Humidity and Temp
  float h = dht.readHumidity();
  float t = dht.readTemperature();

  // 1. Hardware Check
  if (isnan(h) || isnan(t)) {
    lcd.setCursor(0, 0);
    lcd.print("SENSOR ERROR!  ");
    lcd.setCursor(0, 1);
    lcd.print("Check Wiring    ");
    digitalWrite(RED_LED, HIGH);
    digitalWrite(GREEN_LED, LOW);
    return;
  }

  // 2. ML Prediction
  float hic = dht.computeHeatIndex(t, h, false);
  float input[3] = {t, h, hic};
  int prediction = weatherClassifier.predict(input);

  // 3. Anomaly Detection Logic
  bool isAnomaly = false;
  
  // Rule: Sunny but high humidity
  if (prediction == 3 && h > 80.0) isAnomaly = true;
  // Rule: Extreme heat or high humidity for the environment
  else if (t > 45.0 || t < 5.0 || h > 60.0) isAnomaly = true;
  // Rule: Foggy but too hot for fog
  else if (prediction == 0 && t > 30.0) isAnomaly = true;

  // 4. Update LEDs
  if (isAnomaly) {
    digitalWrite(RED_LED, HIGH);
    digitalWrite(GREEN_LED, LOW);
  } else {
    digitalWrite(RED_LED, LOW);
    digitalWrite(GREEN_LED, HIGH);
  }

  // 5. Update LCD Screen
  lcd.setCursor(0, 0);
  lcd.print("T:"); lcd.print(t, 1); lcd.print("C ");
  lcd.setCursor(9, 0);
  lcd.print("H:"); lcd.print(h, 0); lcd.print("%  ");

  lcd.setCursor(0, 1);
  if (isAnomaly) {
    lcd.print("(!) ANOMALY (!) ");
  } else {
    lcd.print("Pred: ");
    switch(prediction) {
      case 0: lcd.print("Foggy  "); break;
      case 1: lcd.print("Rainy  "); break;
      case 2: lcd.print("Cloudy "); break;
      case 3: lcd.print("Sunny  "); break;
      default: lcd.print("Unknown"); break;
    }
  }

  // Serial Monitor for debugging
  Serial.print("T: "); Serial.print(t);
  Serial.print(" H: "); Serial.print(h);
  Serial.print(" Anomaly: "); Serial.println(isAnomaly ? "YES" : "NO");

  delay(2000); // 2-second refresh rate
}